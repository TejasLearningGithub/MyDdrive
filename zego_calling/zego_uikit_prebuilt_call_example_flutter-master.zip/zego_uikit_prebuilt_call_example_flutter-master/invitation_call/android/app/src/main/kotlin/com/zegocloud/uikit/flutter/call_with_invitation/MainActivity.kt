package com.zegocloud.uikit.flutter.call_with_invitation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
