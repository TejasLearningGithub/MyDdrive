package com.zegocloud.zegouikit.example.prebuiltcall

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
