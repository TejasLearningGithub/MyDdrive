package com.zegocloud.uikit.flutter.call

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
