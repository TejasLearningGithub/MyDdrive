package com.zegocloud.uikit.flutter.group_call

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
